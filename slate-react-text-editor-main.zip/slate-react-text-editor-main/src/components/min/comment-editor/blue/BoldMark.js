import React from "react";

const BoldMark = props => <strong>{props.children}</strong>;

export default BoldMark;
